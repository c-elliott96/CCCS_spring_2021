cat pgfshell_cos.out
